## DaddyBomber⚡⚡⚡⚡⚡⚡⚡⚡

<h1 align="center">
  <br>
  <a href="https://github.com/MaybePiyush/DaddyBomber"><img src="https://horoshop.ua/content/images/16/kak-sdelat-chtoby-pisma-ne-popadali-v-spam-11248663734326.jpg" alt="DaddyBomber"></a>
  <br>
  DaddyBomber⚡⚡⚡
  
</h1>



##

<h3 align="center">
:: Workflow ::
</h3>
<p align="center">
<img src="https://images.prismic.io/pepipost/e3269b46-fa9c-4a6f-945a-eccc268cd2dd_types+of+emails+scam.gif?auto=compress,format"/>
</p>
 

## About Tool:

- The script requires working network connection to work.
- No balance will be deducted for using this script to send SMS/calls.
- While doing infinite bombing use 2-3 seconds delay and 10 to 20 threads for maximum performance.
- Don't put spaces in between phone number (Ex- 99999 99999)
- Make sure you are using the latest version of DaddyBomber
- Make sure you are using Python3.

## Features:

- sms bombing
- call bombing
- mail bombing
- whatsapp bombing
- Frequent updates

## Available On
- Termux
- Kali Linux
- macOS


## Test On:
- Termux
- Mi Note 9 pro

## INSTALLATION [Termux] :

* `apt update`
* `apt upgrade`
* `pkg install python`
* `pkg install python2`
* `pkg install git`
* `git clone https://github.com/MaybePiyush/DaddyBomber`
* `ls`
* `cd DaddyBomber`
* `pip2 install -r requirements.txt`
* `chmod +x DaddyBomber.sh`
* `./DaddyBomber.sh Or bash DaddyBomber.sh`

## INSTALLATION [Kali Linux] :

* `sudo apt install python`
* `sudo apt install python2`
* `sudo apt install git`
* `git clone https://github.com/MaybePiyush/DaddyBomber`
* `ls`
* `Now in root permission do`
* `cd DaddyBomber`
* `pip install -r requirements.txt`
* `chmod +x DaddyBomber`

* `now open a new terminal again and without giving root permission` 
* `cd DaddyBomber`
* `./DaddyBomber.sh Or bash DaddyBomber.sh`

## INSTALLATION macOS:

* `brew install git`
* `brew install python3`
* `sudo easy_install pip`
* `sudo pip install --upgrade pip`
* `git clone https://github.com/MaybePiyush/DaddyBomber`
* `cd DaddyBomber`
* `chmod +x DaddyBomber`
* `bash DaddyBomber.sh`


## Warning:
#### This tool is only for educational purpose. If you use this tool for other purposes except education we will not be responsible in such cases
  
  

## LOVE YOU 3000!⚡

  



 ## THANKS!  
   Enjoy ✔
 ## 
    🔴🔴🔴🔴  🔴   🔴  🔴 🔴    🔴 🔴   🔴    🔴     🔴  🔴🔴🔴
        🔴      🔴🔴🔴  🔴  🔴    🔴  🔴  🔴    🔴  🔴    🔴__\
        🔴      🔴   🔴 🔴🔴 🔴   🔴   🔴 🔴    🔴🔴 🔴       🔴
        🔴      🔴   🔴🔴     🔴   🔴    🔴🔴    🔴     🔴 🔴🔴🔴


# THANKS FOR USING! LOVE YOU!⚡⚡⚡✔

